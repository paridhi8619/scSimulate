#' @title Simulate single cell counts
#' @description Simuate single cell counts using gamma distributed cell and size factors
#' @param n_genes integer(1) number of genes to simulate
#' @param n_cells integer(1) numbe rof cell s to simulate
#' @param rate numeric(1) parameter of the gamma distribution
#' used to simulate gene means
#' @param shape numeric(1) parameter of teh gamma distribution used to simulate gene menas
#' @param dispersion numeric(1) parameter of negative binomial ditribution used to simulate the counts.
#'
#' @examples
#' counts <- simulate()
#' dim(counts)
#' hist(rowSums(counts))
#' @importFrom stats rgamma rnorm rnbinom
#' @export
simulate <- function(n_genes = 20000, n_cells = 100, rate = 0.1, shape = 0.1, dispersion = 0.1){
  gene_means <- rgamma(n_genes, shape = shape, rate = rate)
  cell_size_factors <- 2 ^ rnorm(n_cells, sd = 0.5)
  cell_means <- outer(gene_means, cell_size_factors, `*`)
  matrix(
    rnbinom(n_genes * n_cells, mu = cell_means, size = 1 / dispersion),
    nrow = n_genes, ncol = n_cells
  )
  # return(counts)
}




